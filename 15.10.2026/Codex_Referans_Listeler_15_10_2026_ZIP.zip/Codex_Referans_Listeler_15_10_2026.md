# Codex Referans Listeler — 15.10.2026

## Hedef
Google Drive: `15.10.2026 Model Bağımsız Çalışmaları/001-Kayıt Notları ve Dokümantasyon/003-Referans Kaynaklar`
https://drive.google.com/drive/folders/1o-XbrVAd7oMRR1fW2IgVZCtgLSXovKEE

## Çalışma talimatı
Mevcut klasörleri ve dosyaları koru. Önce envanter çıkar, ardından dry-run yerleştirme planı oluştur. URL'leri ve lisansları kontrol et. Yalnızca doğrulanabilen kaynakları ilgili klasörlere manifest/README olarak kaydet. Üçüncü taraf videoları ve belgeleri izinsiz indirme. Güncel ilanların başvuru durumunu doğrulamadan 'açık' deme. Her kayıt için `id, title, url, platform, project, use, version, checked_at, status, evidence_class, license` alanlarını tut. Tamamlanınca dosya bazında sonuç raporu oluştur.

## 001-Oynatma Listesi İçerikleri
- YT-01 Phil's Lab — Switching Regulator Component Selection: https://fedevel.com/blog/switching-regulator-component-selection-sizing-phils-lab-71
- YT-02 Phil's Lab — Switching Regulator PCB Layout (arama; tekil video değil): https://www.youtube.com/results?search_query=Phil%27s+Lab+switching+regulator+PCB+layout
- YT-03 ESP32-S3 USB Host (arama): https://www.youtube.com/results?search_query=Espressif+ESP32-S3+USB+Host
- YT-04 KiCad/KiBot automation (arama): https://www.youtube.com/results?search_query=KiCad+KiBot+automation+ERC+DRC

## 002-PDF'ler
- PDF-01 ESP32-S3 Hardware Design Guidelines: https://docs.espressif.com/projects/esp-hardware-design-guidelines/en/latest/esp32s3/index.html
- PDF-02 ESP32-S3 Technical Reference Manual: https://documentation.espressif.com/esp32-s3_technical_reference_manual_en.pdf
- PDF-03 ESP-IDF USB Host API: https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/peripherals/usb_host.html
- PDF-04 ESP32-S3 USB-OTG User Guide: https://documentation.espressif.com/esp-dev-kits/en/latest/esp32s3/esp32-s3-usb-otg/index.html
- PDF-05 TPS2553: https://www.ti.com/product/TPS2553
- PDF-06 TPS2553-1: https://www.ti.com/product/TPS2553-1
- PDF-07 TPS2051C: https://www.ti.com/product/TPS2051C
- PDF-08 LM7480-Q1: https://www.ti.com/lit/ds/symlink/lm7480-q1.pdf
- PDF-09 KiCad CLI: https://docs.kicad.org/9.0/en/cli/cli.html
- PDF-10 KiBot: https://kibot.readthedocs.io/
- PDF-11 ngspice: https://ngspice.sourceforge.io/docs.html
HTML sayfalarını PDF gibi etiketleme; mümkünse resmî PDF bağlantısını kaydet.

## 003-Repolar
- GH-01 ESP-IDF USB MSC Host: https://github.com/espressif/esp-idf/tree/master/examples/peripherals/usb/host/msc
- GH-02 ESP-IDF USB Host Library: https://github.com/espressif/esp-idf/tree/master/examples/peripherals/usb/host/usb_host_lib
- GH-03 esp-usb: https://github.com/espressif/esp-usb
- GH-04 pytest-embedded: https://github.com/espressif/pytest-embedded
- GH-05 KiBot: https://github.com/INTI-CMNB/KiBot
- GH-06 Hypothesis: https://github.com/HypothesisWorks/hypothesis
- GH-07 USB issue #18409: https://github.com/espressif/esp-idf/issues/18409
- GH-08 USB issue #15938: https://github.com/espressif/esp-idf/issues/15938
- GH-09 USB issue #12142: https://github.com/espressif/esp-idf/issues/12142
- GH-10 KiBot issue #811: https://github.com/INTI-CMNB/KiBot/issues/811
- GH-11 KiBot issue #874: https://github.com/INTI-CMNB/KiBot/issues/874
- GH-12 USB issue #18366: https://github.com/espressif/esp-idf/issues/18366
- GH-13 USB issue #18106: https://github.com/espressif/esp-idf/issues/18106
- GH-14 USB issue #15079: https://github.com/espressif/esp-idf/issues/15079
Her depo için commit/tag, lisans ve hedef ESP-IDF/KiCad sürümünü belirt. Issues/PR'leri yayımlanmış düzeltme olarak varsayma.

## 004-Müşteri Referansları
Bunlar gerçek müşteri referansları değil, kamuya açık ilanlardan türetilmiş **müşteri talep profilleridir**.
- CR-01 24 V ESP32-S3 Controller: https://www.upwork.com/freelance-jobs/apply/ESP32-24V-Bus-Controller-KiCad-Schematic-Layer-PCB_~022102350346911347999/
- CR-02 IoT Gateway Independent Review: https://www.upwork.com/freelance-jobs/apply/Independent-Review-Layer-IoT-Gateway-PCB-Schematic-Layout-BOM-Before-Production-Order_~022099232653551877485/
- CR-03 Pre-Layout Review: https://www.upwork.com/freelance-jobs/apply/Pre-Layout-Board-Design-Review-and-Verification_~022105122633599453191/
- CR-04 CAN/LIN/GNSS: https://www.upwork.com/freelance-jobs/apply/KiCad-Schematic-and-PCB-Design-ESP32-CAN-LIN-GNSS_~022096334976197568424/

## 005-İş İlanı
- JOB-01 ESP32-S3 24V Controller: https://www.upwork.com/freelance-jobs/apply/ESP32-24V-Bus-Controller-KiCad-Schematic-Layer-PCB_~022102350346911347999/
- JOB-02 LilyGO ESP32 Sensor Carrier: https://www.upwork.com/freelance-jobs/apply/KiCad-PCB-Layout-IoT-Sensor-Carrier-Board-for-LilyGO-Solar-Enclosure-ESP32_~022110997593431975316/
- JOB-03 STM32G4 Architecture: https://www.upwork.com/freelance-jobs/apply/STM32G4-firmware-architecture-for-premium-sim-racing-wheel-Phase-document-only_~022111013266287155573/
- JOB-04 CAN FD Logger: https://www.upwork.com/freelance-jobs/apply/KiCad-PCB-Designer-Needed-Layer-CAN-Logger-USB-and-Ethernet_~022110478124258050943/
- JOB-05 ESP32-S3 Audio Layout: https://www.upwork.com/freelance-jobs/apply/KiCad-PCB-Layout-for-ESP32-Audio-Device-JLCPCB-Manufacturing-Files_~022109696715865787700/

## Pinterest ve Scribd
Pinterest için görsel referans kayıtlarını ve Scribd için teknik belge keşif kayıtlarını mevcut klasör yapısını bozmadan ayrı CSV dosyalarında tut. Öncelik resmî üretici belgesindedir. Önceden doğrulanmamış pin veya belge URL'si uydurma.

## Kabul koşulları
1. Öncesi/sonrası klasör envanteri ve dry-run planı.
2. Her kaynak için URL doğrulama, sürüm, lisans, erişim durumu ve REP-01/02/03 eşleştirmesi.
3. Tekilleştirilmiş kaynak listeleri ve bozuk bağlantı raporu.
4. Mevcut dosyaların korunması; hiçbir silme/üzerine yazma olmaması.
5. `completion-report.md`: oluşturulan dosyalar, atlanan kayıtlar, engeller ve bağlantılar.

## Codex'e verilecek prompt
Bu raporu oku. 15.10.2026 Model Bağımsız Çalışmaları klasörünün mevcut `003-Referans Kaynaklar` alt klasörlerini doldurmak üzere önce envanter ve dry-run planı hazırla. Yetki ve erişim uygunsa mevcut içerikleri koruyarak doğrulanmış bağlantı manifestoları, açıklama dosyaları ve doğrulama günlüğü oluştur. Kaynakları REP-01/02/03 ve gereksinimlerle eşleştir. Doğrulanamayan kayıtları açıkça işaretle. Kod push/PR, iş başvurusu veya üçüncü taraf içerik indirmesi yapma. Sonuçları dosya bazında raporla.
