# PF-04 — Copilot CLI Handoff & Technical Execution Report

**Version:** 1.0  
**Date:** 2026-10-30  
**Project:** `power-circuit-review-case`  
**Workspace:** `Portfolyo/29.10.2026/002-Proje Çıktıları/power-circuit-review-case`  
**Scope:** PF-04 only  
**Initial mode:** READ-ONLY / RESEARCH-FIRST

## 1. Mission

Inspect the existing PF-04 workspace and determine the shortest technically defensible route toward a client-facing Power Circuit Review Case. Do not implement changes before completing the initial inspection and reporting phase.

Expected deliverables after approval: verified schematic section, annotated review, component/datasheet inventory, reproducible conduction-loss calculation, automated synthetic tests, risk matrix, client-facing report, and traceable commits.

## 2. Verified workspace status and research leads

The existing PF-04 README describes a **candidate** high-side load switching section from `LibreSolar/mppt-2420-hc` (https://github.com/LibreSolar/mppt-2420-hc). It reports:

- Workspace: `SCAFFOLD`; demo and tests: `NOT_RUN`.
- First task: `T00 Devre bölümünü doğrula`.
- Synthetic input cases: 1 A, 3 A and 5 A.
- Source commit, exact schematic sheet, component references, thermal conditions and license basis: **not verified**.
- No physical measurements have been performed.

**Unverified research leads** (not confirmed BOM facts): `IPA045N10N3G`, `INA186`, `DCDC_LV+`, `LOAD+`, `LOAD_DIS`, `CP_OUT`, `I_LOAD`, `I_LOAD_COMP`.

The source-lock file records the upstream LibreSolar repository as `UNVERIFIED`, with null commit and license basis. Do not claim these fields are verified until independently checked.

## 3. Phase A — Mandatory read-only inspection

1. Inventory the PF-04 repository tree, README, `sources.lock.json`, config, examples, tests, demo and docs.
2. Read the adjacent PF-04 İş Akışı and Codex Görev Planı reports if accessible.
3. Inspect Git status, branch, remotes, HEAD and commit history; distinguish empty history from inaccessible history.
4. Classify each file as functional, placeholder, synthetic input or evidence.
5. Identify blockers and minimum changes needed to preserve the current structure.
6. **Stop and report.** Do not edit files, install dependencies, create commits or push.

## 4. Phase B — GitHub upstream verification

Verify the upstream repository URL, immutable commit SHA, license and reuse requirements; locate the exact high-side load-switch schematic, hierarchical sheet, page, net boundaries, refdes, full part numbers and BOM. Cross-check relevant datasheets. If verification fails, mark the source-based circuit review `BLOCKED`; synthetic calculation work may be proposed separately, clearly labeled.

## 5. Phase C — Google Patents technical comparison

Initial candidates for **verification**, not assumed matches:

- https://patents.google.com/patent/US20060001457A1/en
- https://patents.google.com/patent/US7372685B2/en
- https://patents.google.com/patent/US9007100B2/en
- https://patents.google.com/patent/US20240128964A1/en

For each: verify publication and family, review independent claims and figures, identify the claimed mechanism, compare against verified LibreSolar schematic evidence, classify the relation as direct / partial / conceptual / unrelated, and state what engineering review criterion it informs. Do not infer infringement or freedom-to-operate conclusions.

## 6. Phase D — Engineering analysis plan

**MOSFET:** gate-drive adequacy, `RDS(on)` at relevant `VGS` and temperature, conduction loss, voltage/current stress, transients and SOA.

**Current sensing:** shunt value/tolerance, shunt dissipation, amplifier common-mode range, gain, saturation and uncertainty.

**Protection:** charge pump, `VGS` limits, enable/disable behavior, reverse current, overcurrent threshold and response.

Base equations:

- `P_MOSFET_conduction = I^2 * RDS_on`
- `P_shunt = I^2 * R_shunt`

Distinguish steady-state load-switch behavior from repetitive switching; do not invent a switching frequency. Separate datasheet values, schematic facts, assumptions, synthetic examples and physically unverified outcomes.

## 7. Phase E — Proposed implementation (only after approval)

Minimal Python pipeline: component/source inventory, validated synthetic scenario loader, loss calculation, tests and HTML/PDF reporting. Suggested test coverage: 1/3/5 A, zero current, negative resistance rejection, missing input, unit conversion, quadratic scaling and uncertainty flags.

Tests establish calculation consistency, **not hardware safety or thermal performance**.

## 8. Evidence and reporting

Store actual execution evidence at `003-Proje Kayıtları/PF-04/<run-id>/` including source revision, input hashes, commands, test outputs, generated reports, limitations and acceptance decision. Never fabricate logs, measurement traces, screenshots or passing tests.

## 9. Proposed atomic commit sequence (not yet executed)

1. `docs(pf04): verify upstream circuit and source provenance`
2. `docs(pf04): map load-switch components and interfaces`
3. `feat(pf04): add reproducible conduction-loss model`
4. `test(pf04): cover synthetic loss and invalid inputs`
5. `docs(pf04): add circuit risk and validation matrix`
6. `docs(pf04): prepare client-facing review case`

## 10. Guardrails

- PF-04 only; do not touch PF-01/02/03/05.
- Preserve existing directory structure where possible.
- No physical testing or fabricated measurements.
- No unverified thermal, current-rating or safety claims.
- No destructive Git operations, automatic pushes, dependency installation or commits without approval.
- Initial session is read-only; pause before implementation.

## 11. Required first response from Copilot CLI

Return a structured **inspection-only** report with:

1. Repository inventory and current Git state.
2. Verified upstream revision/license status.
3. Circuit boundaries and component verification status.
4. Patent research findings with evidence links.
5. Missing information and blockers.
6. Minimum viable implementation proposal.
7. File-by-file proposed changes.
8. Proposed commit count and sequence.
9. Test/acceptance plan and limitations.
10. Explicit decisions requiring user approval.

**STOP after this report and wait for approval.**

## Reference documents

- PF-04 İş Akışı v1: https://drive.google.com/file/d/1laFKrZo5KfN0pQ49Sum2n_aSQLEElYln/view
- PF-04 Codex Görev Planı v1: https://drive.google.com/file/d/1CJdiW5WDv_pfzAUzfucU4Bgo-_uqqZHl/view
- PF-04 workspace folder: https://drive.google.com/drive/folders/1skb75rnAiimNXo63wLVPu0OeIaO4hmrW

*Prepared from the PF-04 workspace information and earlier research leads. Upstream source and patent claim-level verification remain pending.*
