import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True)
version = subprocess.check_output(["kicad-cli", "version"], text=True)
(output / "version.txt").write_text(version)

inputs = root / "fixtures"
def inventory():
    return {
        str(source.relative_to(root)): hashlib.sha256(source.read_bytes()).hexdigest()
        for source in sorted(inputs.rglob("*")) if source.is_file()
    }

before = inventory()
reports = {}
for case, expected_code in (("clean", 0), ("unpowered", 5)):
    case_dir = output / case
    case_dir.mkdir()
    config = output / "config"
    settings = config / "kicad" / ".".join(version.strip().split(".")[:2])
    settings.mkdir(parents=True, exist_ok=True)
    table_text = (inputs / case / "sym-lib-table").read_text()
    (settings / "sym-lib-table").write_text(table_text.replace("KICAD9_SYMBOL_DIR", f"KICAD{version.strip().split('.')[0]}_SYMBOL_DIR"))
    shutil.copyfile(os.environ.get("KICAD_FP_TABLE", "/usr/share/kicad/template/fp-lib-table"), settings / "fp-lib-table")
    env = {**os.environ, "XDG_CONFIG_HOME": str(config), "XDG_CACHE_HOME": str(output / "cache"), "LC_ALL": "C"}
    for report_format, filename in (("json", "erc.json"), ("report", "erc.rpt")):
        command = ["kicad-cli", "sch", "erc", "--units", "mm", "--format", report_format,
                   "--severity-all", "--exit-code-violations", "-o", filename,
                   str(inputs / case / "erc.kicad_sch")]
        result = subprocess.run(command, cwd=case_dir, env=env, capture_output=True, text=True)
        (case_dir / f"{report_format}.log").write_text(result.stdout + result.stderr)
        (case_dir / f"{report_format}.exit").write_text(f"{result.returncode}\n")
        (case_dir / f"{report_format}.command.json").write_text(json.dumps(command) + "\n")
        assert result.returncode == expected_code, (case, report_format, result.returncode)
    report = json.loads((case_dir / "erc.json").read_text())
    violations = [violation for sheet in report["sheets"] for violation in sheet["violations"]]
    expected = [("power_pin_not_driven", "error")] if case == "unpowered" else []
    assert [(item["type"], item["severity"]) for item in violations] == expected
    if violations:
        assert report["sheets"][0]["path"] == "/"
        assert violations[0]["items"][0]["uuid"] == "20000000-0000-4000-8000-000000000001"
        assert "@(50.80 mm, 50.80 mm)" in (case_dir / "erc.rpt").read_text()
        print("Ham JSON koordinatı", violations[0]["items"][0]["pos"])
    del report["date"]
    reports[case] = report
    (case_dir / "normalized.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")

after = inventory()
for label, values in (("before", before), ("after", after)):
    (output / f"checksums.{label}.json").write_text(json.dumps(values, indent=2) + "\n")
assert before == after
print("Temiz şema ve tek kusurlu örnek beklenen ERC sonuçlarını verdi.")
