"""Replay the three checks on the supplied synthetic KiCad 9.0.2 exports."""
import csv
import json
import math
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "cases"
OUT.mkdir(exist_ok=True)
HOLES = {"H1", "H2", "H3"}
DEVICES = {"U1", "U2", "U3", "U4", "U5"}

def pads_on(side):
    text = (ROOT / "gerbers" / f"sensor-{side}_Cu.gbr").read_text()
    assert "%FSLAX46Y46*%" in text and "%MOMM*%" in text
    points = {}
    current = None
    for line in text.splitlines():
        if line.startswith("%TD"):
            current = None
        match = re.fullmatch(r"%TO\.P,([A-Z0-9]+),(\d+)\*%", line)
        if match:
            current = match.groups()
        flash = re.fullmatch(r"X(-?\d+)Y(-?\d+)D03\*", line)
        if current and flash:
            assert current not in points
            points[current] = tuple(int(v) / 1e6 for v in flash.groups())
            current = None
    return points

def directions(top, bottom):
    angles = {}
    for ref in sorted(DEVICES):
        layers = [(s, pts) for s, pts in [("top", top), ("bottom", bottom)] if (ref, "1") in pts]
        assert len(layers) == 1
        side, pts = layers[0]
        x1, y1 = pts[ref, "1"]
        x2, y2 = pts[ref, "2"]
        dx, dy = x1-x2, y1-y2
        assert math.hypot(dx,dy) > 0
        angle = math.degrees(math.atan2(dx if side == "bottom" else -dx, dy)) % 360
        angles[ref] = side, angle
    return angles

def write_placement(rows, broken):
    target = OUT / ("mirror-error.csv" if broken else "reference.csv")
    with target.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Designator","Mid X","Mid Y","Rotation","Layer"])
        for row in rows:
            a = float(row["Rot"])
            if row["Side"] == "bottom":
                a = 180+a if broken else 180-a
            writer.writerow([row["Ref"], row["PosX"], row["PosY"], a%360, row["Side"]])
    return target

def placement_errors(target, expected):
    with target.open(newline="") as f:
        rows = list(csv.DictReader(f))
    assert Counter(r["Designator"] for r in rows) == Counter(DEVICES)
    found = {}
    for row in rows:
        ref = row["Designator"]
        side, angle = expected[ref]
        assert row["Layer"] == side
        error = abs((float(row["Rotation"])-angle+180)%360-180)
        if error > 1e-6:
            found[ref] = error
    return found

def drill_offsets(text, top, bottom):
    assert "METRIC" in text
    hits = [tuple(map(float, m)) for m in re.findall(r"^X([\d.-]+)Y([\d.-]+)$", text, re.M)]
    assert len(hits) == len(HOLES)
    used, errors = set(), {}
    for ref in sorted(HOLES):
        p = top[ref,"1"]
        assert p == bottom[ref,"1"]
        h = min(hits, key=lambda q: math.dist(p,q))
        assert h not in used
        used.add(h)
        dx, dy = round(h[0]-p[0],6), round(h[1]-p[1],6)
        if dx or dy:
            errors[ref] = [dx,dy]
    return errors

def missing_layers(folder):
    indices = []
    for path in sorted(folder.glob("*.gbr")):
        role = re.search(r"%TF\.FileFunction,Copper,L(\d+),\w+\*%", path.read_text())
        assert role
        indices.append(int(role[1]))
    assert len(indices) == len(set(indices))
    return sorted({1,2,3,4}-set(indices))

top, bottom = pads_on("F"), pads_on("B")
expected = directions(top,bottom)
with (ROOT / "pos.csv").open(newline="") as f:
    rows = list(csv.DictReader(f))
ref_errors = placement_errors(write_placement(rows,False), expected)
flipped = placement_errors(write_placement(rows,True), expected)
raw = (ROOT / "drill" / "sensor.drl").read_text()
shifted, changes = re.subn(r"^X([\d.-]+)Y",lambda m:f"X{float(m[1])+1.0:.3f}Y",raw,flags=re.M)
assert changes == 3
(OUT / "offset-x.drl").write_text(shifted)
original = drill_offsets(raw,top,bottom)
shift = drill_offsets(shifted,top,bottom)
complete, partial = missing_layers(ROOT/"gerbers"), missing_layers(ROOT/"outer_only")
assert not ref_errors and flipped == {"U2":180.0,"U4":180.0}
assert not original and shift == {k:[1.0,0.0] for k in HOLES}
assert not complete and partial == [2,3]
result = {"placement_reference_errors_deg": ref_errors,"placement_mirror_errors_deg": flipped,
          "drill_reference_errors_mm": original,"drill_shift_residuals_xy_mm":shift,
          "missing_copper_layers_reference":complete,"missing_copper_layers_outer_only":partial}
print(json.dumps(result,indent=2))
