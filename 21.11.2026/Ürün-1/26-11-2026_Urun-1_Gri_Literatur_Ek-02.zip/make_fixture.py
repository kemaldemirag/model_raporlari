from pathlib import Path
import pcbnew as p

root = Path(__file__).resolve().parent
b = p.BOARD()
b.SetCopperLayerCount(4)

def pos(x, y):
    return p.VECTOR2I(p.FromMM(x), p.FromMM(y))

def add_device(ref, x, y, smd, bottom=False, angle=0):
    fp = p.FOOTPRINT(b)
    fp.SetFPID(p.LIB_ID("Test", "Sensor3" if smd else "PTH"))
    fp.SetReference(ref)
    fp.SetValue("sensor_fixture" if smd else "registration_pad")
    fp.SetAttributes(p.FP_SMD if smd else p.FP_THROUGH_HOLE)
    for n, (dx, dy) in enumerate([(-1, -0.75), (-1, 0.75), (1, 0)] if smd else [(0, 0)], 1):
        pad = p.PAD(fp)
        pad.SetNumber(str(n))
        pad.SetAttribute(p.PAD_ATTRIB_SMD if smd else p.PAD_ATTRIB_PTH)
        pad.SetLayerSet(p.PAD.SMDMask() if smd else p.PAD.PTHMask())
        pad.SetShape(p.PAD_SHAPE_RECT if smd else p.PAD_SHAPE_CIRCLE)
        pad.SetSize(pos(.6,.6) if smd else pos(1.6,1.6))
        if not smd:
            pad.SetDrillSize(pos(.8,.8))
        pad.SetPosition(pos(dx,dy))
        fp.Add(pad)
    fp.SetPosition(pos(x,y))
    if bottom:
        fp.Flip(fp.GetPosition(), p.FLIP_DIRECTION_LEFT_RIGHT)
    fp.SetOrientationDegrees(angle)
    b.Add(fp)

for i, a in enumerate([0, 90, 180, 270]):
    add_device(f"U{i+1}", 22+i*6, 15, True, True, a)
add_device("U5", 22, 21, True)
for ref, x,y in [("H1",21,30),("H2",35,28),("H3",41,34)]:
    add_device(ref,x,y,False)
for a, z in [((16,10),(46,10)), ((46,10),(46,38)), ((46,38),(16,38)), ((16,38),(16,10))]:
    edge = p.PCB_SHAPE(b)
    edge.SetShape(p.SHAPE_T_SEGMENT)
    edge.SetLayer(p.Edge_Cuts)
    edge.SetStart(pos(*a))
    edge.SetEnd(pos(*z))
    edge.SetWidth(p.FromMM(.05))
    b.Add(edge)
for layer, y in [(p.In1_Cu,23), (p.In2_Cu,25)]:
    track = p.PCB_TRACK(b)
    track.SetLayer(layer)
    track.SetWidth(p.FromMM(.3))
    track.SetStart(pos(26,y))
    track.SetEnd(pos(32,y))
    b.Add(track)
p.SaveBoard(str(root / "sensor.kicad_pcb"), b)
