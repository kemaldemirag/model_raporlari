# SF-Motion, DRV8323 ve URDF kaynak özeti

21.11.2026 Araştırma Kayıtları · 26.11.2026

## Motor sürücü ve üretim dosyaları

- **SF-Motion.** STM32 tabanlı BLDC/PMSM motor kontrol projesi. Gömülü FOC yazılımı, KiCad kaynakları, Gerber ve BOM, Python iletişim araçları ve test arayüzü yayımlıyor. Ürün-1 için gerçek proje dosyalarıyla ERC, DRC ve şema–PCB eşliği denemesi yapmaya aday. Üretim ve montaj denetiminin kapsamı, seçilen revizyondaki dosyaların envanterine bağlı. Bu kaynak incelemesinde depo üzerinde denetim çalıştırılmadı. [GitHub deposu](https://github.com/sirojudinMunir/sf-motion)
- **TI DRV832x Rev. D.** Sürücü ailesinin pinlerini, kapı sürme beslemesini, PWM seçeneklerini, akım ölçümünü ve korumalarını açıklıyor. Üst kol kapı sürücüleri şarj pompasından besleniyor. TI’nin uygulama tablosu VCP–VM için 1 µF, CPH–CPL için 47 nF ve motor beslemesine uygun gerilim sınıfı veriyor. DRV8323R’deki CB–SW bağlantısı ayrı buck regülatörü bootstrap devresine ait. [Veri sayfası](https://www.ti.com/lit/ds/symlink/drv8323.pdf)
- **TI DRV8323 ürün sayfası.** Parça için 6–60 V çalışma aralığı ve 65 V mutlak üst sınır bildiriyor. Tam motor kartının gerilim sınırı; güç katı, diğer bileşenler ve geçici bara yükselmeleri ayrıca değerlendirilerek belirlenir. [Ürün sayfası](https://www.ti.com/product/DRV8323)
- **TI BOOSTXL-DRV8323Rx.** Aynı sürücü ailesinin örnek kart üzerindeki uygulamasını gösteren üretici kılavuzu. Genel bootstrap hesapları, önce hangi besleme topolojisinin kullanıldığı saptanarak yorumlanmalı. [EVM kılavuzu](https://www.ti.com/lit/ug/slvub01c/slvub01c.pdf) · [TI bootstrap uygulama notu](https://www.ti.com/lit/an/slua887a/slua887a.pdf)
- **INA240A1 şönt hesabı.** 3 mΩ ve 20 V/V ile duyarlılık 60 mV/A. 1,65 V orta noktayla ±25 A idealde 0,15–3,15 V çıkış verir. INA240 3,3 V ile beslendiğinde, TI’nin 10 kΩ yük ve belirtilen sıcaklık aralığı için verdiği üst çıkış payı kullanılırsa 3,10 V sınırı esas alınır. Bu koşullarda ±25 A doğrusal aralığı garanti edilemez. [INA240 veri sayfası](https://www.ti.com/lit/ds/symlink/ina240.pdf)

## Robot eklemi kaynakları

| Kaynak | Sağladığı işlev |
|---|---|
| [solidworks_urdf_exporter2](https://github.com/jsk-ros-pkg/solidworks_urdf_exporter2) | SolidWorks montaj ilişkilerinden eklemleri çıkarıp URDF üretir. İlk çıkarım Windows ve kurulu SolidWorks gerektirir. Mevcut URDF düzenleme ve dışa aktarma Linux ve macOS’ta da çalışır. |
| [lesson_urdf](https://github.com/olmerg/lesson_urdf) | ROS 2 ve RViz’de robot kolu modelini açan eğitim paketi. Eklem durumları arayüzden değiştirilebilir. |
| [URDFParser](https://github.com/robot-acceleration/URDFParser) | URDF parçalarını, eklemlerini ve dönüşümlerini Python nesneleri üzerinden inceleyen ayrıştırıcı. |
| [robot_state_publisher](https://github.com/ros/robot_state_publisher) | URDF kinematik ağacını ve /joint_states mesajlarını kullanıp bağlantı dönüşümlerini tf2 üzerinden yayımlar. |

Donanımsız deney önerisi, tek döner ekleme örnek açı verisi gönderip isim, sıfır konumu, işaret ve açı dönüşümünü kontrol etmek. SF-Motion ile ROS 2 veri köprüsü veya fiziksel motor entegrasyonu bu incelemede çalıştırılmadı.

## Akademik kaynak

Novotny ve Alley’nin 2013 derlemesi, glikan bileşiminin ve proteinlerdeki bağlanma bölgelerinin incelenmesinde kütle spektrometrisi ile ayırma yöntemlerinin rolünü açıklıyor. Görseldeki bölüm, antikor bazlı biyofarmasötiklerde glikan yapısının izlenmesini kalite kontrol örneği olarak ele alıyor. [PubMed kaydı](https://pubmed.ncbi.nlm.nih.gov/23790311/) · [Açık metin](https://pmc.ncbi.nlm.nih.gov/articles/PMC3823762/)
