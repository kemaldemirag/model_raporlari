# Sensör tasarımı kaynak özeti

## TI • Servo konum algılama

Optik, manyetik ve endüktif enkoderler için analog ön uç, düşük gürültülü besleme ve elektromanyetik uyumluluk gereksinimlerini karşılaştırır.

https://www.ti.com/solution/servo-drive-position-sensor

## TI • Doğrusal motor konum algılama

Yüksek bant genişliği, düşük gecikme ve zaman eşlemesi gereksinimlerini doğrusal hareketin geri besleme hattına bağlar.

https://www.ti.com/solution/linear-motor-position-sensor

## TI • LDC5072Q1EVM

Temassız endüktif açı ölçümü için sinüs/kosinüs çıkışlı değerlendirme kartını ve sensör PCB’si tasarım aracını sunar. Geometri ve katman incelemesi için somut bir örnektir.

https://www.ti.com/tool/LDC5072Q1EVM

## TI • SLYA066 uygulama notu

Manyetik ve endüktif algılamayı otomotiv düğmesi ve döner kumanda üzerinden açıklar. Mekanik hedefin sensöre göre konumu tasarım girdisidir.

https://www.ti.com/lit/pdf/slya066

## TI • CapTIvate tasarım kılavuzu

Kapasitif elektrot ve hatların yerleşimini açıklar. Algılama bölgesi dışındaki TX/RX yakınlığı istenmeyen algılamaya yol açabilir.

https://software-dl.ti.com/msp430/msp430_public_sw/mcu/msp430/CapTIvate_Design_Center/1_83_00_08/exports/docs/users_guide/html/CapTIvate_Technology_Guide_html/markdown/ch_design_guide.html

## TI • Karşılıklı kapasitans eğitimi

6 dakika 16 saniyelik video düğme, kaydırıcı ve çark elektrotlarının PCB yerleşimini gösterir. TI sayfası yayın tarihini 30 Ağustos 2016 olarak verir.

https://www.ti.com/video/5104984202001

## Ucamco • Gerber biçim tanımı, 2026.05

Katman işlevi ve koordinat tanımları için birincil başvurudur. Ürün-1’de beklenen katman dizisini üretim dosyalarındaki özniteliklerle karşılaştırmaya dayanak sağlar.

https://www.ucamco.com/en/guest/downloads/gerber-format
