Ürün-1 · K1-01 bakır açıklığı ön doğrulaması · 26.11.2026

KiCad 9.0.2. İki F.Cu izi 0,20 mm genişliğinde ve farklı netlerde.
Kural 0,30 mm. Referans açıklığı 0,80 mm. Kusurlu kopyada yalnız
TRACE_B izi taşındı, açıklık 0,10 mm oldu.

Tüm önem düzeylerinde iki vaka da kod 5 verdi. Her kartta iki
track_dangling uyarısı var. Kusurlu kart ayrıca tek clearance
hatası verdi. Sadece error düzeyinde referans 0, kusurlu 5.
Dolayısıyla K1-01 kararı JSON'daki ihlal türü, önem düzeyi ve
ilgili nesnelerle bağlanır. Çıkış kodu tek başına yeterli ayrım vermez.
Ham JSON iki izin F.Cu katmanını, başlangıç koordinatlarını ve UUID'lerini içeriyor.

Yeniden koşu: python3 reproduce.py yeni-cikti
A/B normalize raporları eşleşti ve kaynak SHA-256 özetleri değişmedi.
Bu bir ön doğrulama. Şema–PCB eşliği ve resmî KiCad 10 K1 paketi bu koşunun dışında.
