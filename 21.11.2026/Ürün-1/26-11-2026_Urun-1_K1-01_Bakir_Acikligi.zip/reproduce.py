import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve()
out.mkdir()
sources = sorted((root / "fixtures").glob("*/*"))

def hashes():
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}

before = hashes()
(out / "version.txt").write_bytes(subprocess.check_output(["kicad-cli", "version"]))
for case in ("clean", "faulty"):
    for scope in ("all", "error"):
        suffix = f"{case}-{scope}"
        path = out / f"{suffix}.json"
        command = ["kicad-cli", "pcb", "drc", "--format", "json", "--units", "mm",
                   f"--severity-{scope}", "--exit-code-violations", "-o", str(path),
                   str(root / "fixtures" / case / "clearance.kicad_pcb")]
        result = subprocess.run(command, capture_output=True)
        (out / f"{suffix}.command.json").write_text(json.dumps(command))
        (out / f"{suffix}.log").write_bytes(result.stdout + result.stderr)
        (out / f"{suffix}.exit").write_text(f"{result.returncode}\n")
        assert result.returncode == (0 if (case, scope) == ("clean", "error") else 5)
        report = json.loads(path.read_text())
        errors = [v for v in report["violations"] if v["severity"] == "error"]
        assert [v["type"] for v in errors] == (["clearance"] if case == "faulty" else [])
        assert not report["unconnected_items"]
        if errors:
            assert "0.3000 mm" in errors[0]["description"] and "0.1000 mm" in errors[0]["description"]
            assert len(errors[0]["items"]) == 2
        report.pop("date", None)
        (out / f"{suffix}.normalized.json").write_text(json.dumps(report, sort_keys=True, indent=2))
after = hashes()
(out / "source-hashes.json").write_text(json.dumps({"before": before, "after": after}, indent=2))
assert before == after
